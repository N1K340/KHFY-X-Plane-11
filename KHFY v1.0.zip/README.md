# KHFY

KHFY Greenwood Airport

Libraries used
- opensceneryX: https://forums.x-plane.org/index.php?/files/file/2226-opensceneryx/&do=download&csrfKey=6e44834c17db8b3b27c492dabcdd4217
- FruitstandAircraft: https://forums.x-plane.org/index.php?/files/file/27545-the-fruit-stand-aircraft-library/&do=download
- CDB-Library: https://forums.x-plane.org/index.php?/files/file/27907-cdb-library/&do=download&csrfKey=6e44834c17db8b3b27c492dabcdd4217
- Handyobjects: https://forums.x-plane.org/index.php?/files/file/24261-the-handy-objects-library/&do=download&csrfKey=6e44834c17db8b3b27c492dabcdd4217
- R2 Library: http://r2.xpl.cz/

 
v1.0 - Initial Release Feb 2022